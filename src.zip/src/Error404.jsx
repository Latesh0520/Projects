import React from 'react'

export default function Error404() {
  return (
    <div>Error404</div>
  )
}
