import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
} from "reactstrap";

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const toggle = () => setIsOpen(!isOpen);

  return (
    <>
      <Navbar expand={'md'}>
        <NavbarBrand href="/">reactstrap</NavbarBrand>
        <NavbarToggler onClick={toggle} />
        <Collapse isOpen={isOpen} navbar>
          <Nav className="me-auto" navbar>
            <NavItem>
              <NavLink to="/"  className={'btn border-0 border-bottom rounded-0 mx-2'}>Home</NavLink>
            </NavItem>
            <NavItem>
              <NavLink to="/todotask"  className={'btn border-0 border-bottom rounded-0 mx-2'}>Todo Task</NavLink>
            </NavItem>
            <NavItem>
              <NavLink to="/donetask"  className={'btn border-0 border-bottom rounded-0 mx-2'}>
                Done Task
              </NavLink>
            </NavItem>            
          </Nav>
        </Collapse>
      </Navbar>
    </>
  );
}
