import { CheckCircle, Edit, Trash } from "lucide-react";
import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { Button, Input, Table } from "reactstrap";
import TodoTask from "./TodoTask";

export default function Home() {
  let [task, setTask] = useState("");
  let [tasksList, setTaskList] = useState([]);
  let [doneTaskList, setDoneTaskList] = useState([]);
  let [AllDoneTaskList, setAllDoneTaskList] = useState([]);
  let [AllDeleteTaskList, setAllDeleteTaskList] = useState([]);
  useEffect((e) => {
    let getTask = JSON.parse(localStorage.getItem("TaskProject"));
    if (getTask) {
      setTaskList(getTask);
    }
    let getDoneTask = JSON.parse(localStorage.getItem("DoneTaskProject"));
    if (getDoneTask) {
      setDoneTaskList(getDoneTask);
    }
  }, []);
  const submitTask = (e) => {
    if (e == "Enter" || e == "submitBtn") {
      if (task) {
        setTaskList([...tasksList, task]);
        localStorage.setItem(
          "TaskProject",
          JSON.stringify([...tasksList, task])
        );
        setTask("");
      } else {
        toast.error("Please Enter task..");
      }
    }
  };
  const taskDoneHandler = (ele, i) => {
    tasksList?.splice(i, 1);

    setTaskList(tasksList);
    localStorage.setItem("TaskProject", JSON.stringify(tasksList));

    setDoneTaskList([...doneTaskList, ele]);
    localStorage.setItem(
      "DoneTaskProject",
      JSON.stringify([...doneTaskList, ele])
    );
  };
  const taskDoneDeleteHandler = (ele, ind) => {
    let confirmDelete = confirm("Do you want delete submitted task... ");
    if (confirmDelete) {
      let upatedTask = doneTaskList?.filter((e, i) => i != ind);
      localStorage.setItem("DoneTaskProject", JSON.stringify(upatedTask));
      setDoneTaskList(upatedTask);
    }
  };
  const checkAllHandlerToDone = (e) => {  
      let selectAll = Object.keys(tasksList).map((key) => +key);
      setAllDoneTaskList(selectAll);
   
  };
  const singleCheckedTaskTodone = (i) => {
    if (AllDoneTaskList.includes(i)) {
      let filterArray = AllDoneTaskList?.filter((e) => e != i);
      setAllDoneTaskList(filterArray);
    } else {
      setAllDoneTaskList([...AllDoneTaskList, i]);
    }
  };
  const taskDoneAllHandler = () => {
    if (AllDoneTaskList?.length == tasksList?.length) {
      setDoneTaskList([...doneTaskList, ...tasksList]);
      localStorage.setItem(
        "DoneTaskProject",
        JSON.stringify([...doneTaskList, ...tasksList])
      );
      setTaskList([]);
      localStorage.setItem("TaskProject", JSON.stringify([]));
    } else {
      let newDoneTasks = [...doneTaskList];
      AllDoneTaskList?.forEach((e, i) => {
        newDoneTasks.push(tasksList[e]);
      });
      let newTodoTasklist = tasksList?.filter(
        (e, i) => !newDoneTasks?.includes(e)
      );

      setDoneTaskList(newDoneTasks);
      localStorage.setItem("DoneTaskProject", JSON.stringify(newDoneTasks));

      setTaskList(newTodoTasklist);
      localStorage.setItem("TaskProject", JSON.stringify(newTodoTasklist));
    }
    setAllDoneTaskList([]);
  };
  let checkAllHandlerToDelete=()=>{
    let selectAll = Object.keys(tasksList).map((key) => +key);
    setAllDoneTaskList(selectAll);
  }
  return (
    <>
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-md-6">
            <div className="row">
              <div className="col-md-8">
                <Input
                  placeholder="Enter task"
                  value={task}
                  onChange={(e) => {
                    setTask(e?.target?.value);
                  }}
                  onKeyDown={(e) => submitTask(e?.key)}
                />
              </div>
              <div className="col-md-4">
                <Button
                  onClick={() => {
                    submitTask("submitBtn");
                  }}
                >
                  Submit
                </Button>
              </div>
            </div>
          </div>
        </div>
        <div className="row mt-5">
          <div className="col-md-6">
            <div className="card p-2">
              <h1 className="text-center">Todo Task</h1>
              <div className="d-flex justify-content-end">
                <span>All</span>
                <Input
                  type="checkbox"
                  onChange={(e) => checkAllHandlerToDone(e)}
                  checked={
                    AllDoneTaskList?.length == tasksList?.length &&
                    AllDoneTaskList?.length > 0
                  }
                />
                <CheckCircle
                  onClick={() => {
                    taskDoneAllHandler();
                  }}
                />
              </div>
              <Table>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Task</th>
                  </tr>
                </thead>
                <tbody>
                  {tasksList?.map((e, i) => {
                    return (
                      <tr key={i}>
                        <td>
                          <span>{i + 1}</span>
                        </td>
                        <td className="">
                          <span className="d-flex justify-content-between">
                            <span>{e}</span>
                            <span>
                              <Input
                                type="checkbox"
                                checked={AllDoneTaskList?.includes(i)}
                                onChange={() => singleCheckedTaskTodone(i)}
                              />
                              <CheckCircle
                                onClick={() => {
                                  taskDoneHandler(e, i);
                                }}
                              />
                            </span>
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </Table>
            </div>
          </div>
          <div className="col-md-6">
            <div className="card p-2">
            <h1 className="text-center">Done Task</h1>
              <div className="d-flex justify-content-end">
                <span>All</span>
                <Input
                  type="checkbox"
                  onChange={() => checkAllHandlerToDelete()}
                 
                />
                <Trash
                  onClick={() => {
                    taskDoneAllDeleteHandler();
                  }}
                />
              </div>
              <Table>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Task</th>
                  </tr>
                </thead>
                <tbody>
                  {doneTaskList?.map((e, i) => {
                    return (
                      <tr key={i}>
                        <td>
                          <span>{i + 1}</span>
                        </td>
                        <td className="">
                          <span className="d-flex justify-content-between">
                            <span>{e}</span>
                            <span>
                              <Input type="checkbox" />
                              <Trash
                                onClick={() => {
                                  taskDoneDeleteHandler(e, i);
                                }}
                              />
                            </span>
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </Table>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
