import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./Home";
import Header from "./Header-Footer/Header";
import TodoTask from "./TodoTask";
import DoneTask from "./DoneTask";
import Error404 from "./Error404";

export default function Router() {
  return (
    <>
      <div className="container">
        <BrowserRouter>
          <Header />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="todotask" element={<TodoTask />} />
            <Route path="donetask" element={<DoneTask />} />
            <Route path="*" element={<Error404 />} />
          </Routes>
        </BrowserRouter>
      </div>
    </>
  );
}
